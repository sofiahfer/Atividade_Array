let animais = ["cachorro", "gato", "elefante", "leão", "tigre"];
for (let i = 0; i < animais.length; i++) {
    console.log(animais[i]);
}