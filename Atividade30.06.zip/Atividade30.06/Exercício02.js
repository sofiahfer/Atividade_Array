let vetorGeral = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
let vetorNumPares = [2, 4, 6, 8, 10];
let vetorNumImpares = [1, 3, 5, 7, 9];
numero = Number(prompt("Digite um número: "));
if(numero % 2 === 0) {
    console.log("O número é par");
}else{
    console.log("O número é ímpar"); 
}